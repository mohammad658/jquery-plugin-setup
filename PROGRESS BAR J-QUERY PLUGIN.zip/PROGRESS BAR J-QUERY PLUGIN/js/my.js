$(document).ready(function(){

  $(function(){

    $('.circlechart').circlechart();
  
  });


})